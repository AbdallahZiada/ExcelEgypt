import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/Class/user';
import { ControlPanelService } from 'src/app/Services/control-panel.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  public userr:User;
  constructor(private controlPanel:ControlPanelService,private router:Router) { 
    this.userr=new User();
  }

  ngOnInit() {
  }

  onSubmit()
  {
    this.addUser()
  }
  addUser()
  {
    this.controlPanel.AddUser(this.userr).subscribe((data)=>{
      this.router.navigate(['/AllUsers']);
    });
  };


}
