import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/Services/user.service';
import { Router } from '@angular/router';
import { Admin } from 'src/app/Class/admin';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public userr:Admin;
  

  constructor(private userService:UserService,private router:Router ) {
    this.userr=new Admin();
  };
   
  submitted = false;

  onSubmit() {
    this.userService.ValidateUser(this.userr).
    subscribe((data)=>{
      this.userService.RememberToken(data.token);
      this.router.navigate(['/']);
      location.reload();
    },(error)=>
    {
      console.log(error);
    });
  }

  ngOnInit() {
    
  }

}
