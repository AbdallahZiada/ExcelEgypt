import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/Class/user';
import { ControlPanelService } from 'src/app/Services/control-panel.service';
import {  Router } from '@angular/router';

@Component({
  selector: 'app-all-users',
  templateUrl: './all-users.component.html',
  styleUrls: ['./all-users.component.css']
})
export class AllUsersComponent implements OnInit {
  public userr:User[];
  public user:User;
  public editflag:boolean;
  public editingId:number;
  constructor(private controlPanel:ControlPanelService,private router:Router) {
    this.userr=[];
    this.user=new User();
   }

  ngOnInit() {
    this.userr=[];
    this.getAllUsers();
  }

  getAllUsers(){
    this.controlPanel.GetUsers().subscribe((data)=>{
      data.forEach(element => {
        this.userr.push(element);
      });
    });
  };

  changeEditFlage(id:number)
  {
    if(this.editflag==true)
      this.editflag=false;
    else
      this.editflag=true;
  }

  updateUserInfo(user:User)
  {
    this.controlPanel.UpdateUser(user).subscribe((data)=>{
    });
  }
  deleteUser(id:number)
  {
    
    this.controlPanel.DeleteUser(id).subscribe((data)=>{
      this.ngOnInit();
    });
  };

  buttonToAddUser(){
    this.router.navigate(['/AddUser']);
  }
}
