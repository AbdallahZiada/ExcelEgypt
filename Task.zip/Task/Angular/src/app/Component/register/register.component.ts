import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/Class/user';
import { UserService } from 'src/app/Services/user.service';
import { Router } from '@angular/router';
import { Admin } from 'src/app/Class/admin';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  public userr:Admin;
  public errors:Array<string>;

  constructor(private userService:UserService,private router:Router) {
    this.userr =new Admin()
   }

  ngOnInit() {
  }

  onSubmit():void {
    this.userService.register(this.userr).subscribe(
      (user)=>
      {
        this.userService.ValidateUser(this.userr).subscribe((token)=>{
          this.userService.RememberToken(JSON.stringify(token));
          this.router.navigate(['/']);
          location.reload();
        },(error)=>
        {
          console.log(error);
        }
        );
      },
      (error)=>
      {
        for(var d in error.error.ModelState)
        {
          this.errors=error.error.ModelState[d];
        }
      }
      );
  }
  
}
