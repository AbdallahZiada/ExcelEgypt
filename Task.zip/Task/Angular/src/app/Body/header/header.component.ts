import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  IsLogged : boolean;
  constructor(private router:Router) { 
    this.IsLogged=false;
  }

  ngOnInit() {
    if(localStorage.getItem("access_token"))
    {
      this.IsLogged=true;
    }
    else
    {
      this.IsLogged=false;
    }
  }

  logout() : void
  {
    localStorage.removeItem("access_token");
    this.router.navigate(['/login']);
    location.reload();
  }  

}
