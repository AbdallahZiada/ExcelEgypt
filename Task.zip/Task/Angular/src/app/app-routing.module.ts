import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './Component/login/login.component';
import { RegisterComponent } from './Component/register/register.component';
// import { AuthGuard } from './Services/page-guard.service';
// import { LoginGuardService } from './Services/login-guard.service';
import { AllUsersComponent } from './Component/all-users/all-users.component';
import { AddUserComponent } from './Component/add-user/add-user.component';
import { AuthGuard } from './Services/page-guard.service';

const routes: Routes = [
  {path:'AllUsers',component:AllUsersComponent,
  canActivate:[AuthGuard],
  },
  {path:'AddUser',component:AddUserComponent,
     canActivate:[AuthGuard],
  },
  {path:'login',component:LoginComponent,
     canActivate:[AuthGuard],
  },
  {path:'register',component:RegisterComponent,
     canActivate:[AuthGuard],
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
