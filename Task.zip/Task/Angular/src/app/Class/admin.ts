export class Admin {
    public Email:string;
    public UserName:string;
    public Password:string;
    public ConfirmPassword:string;
constructor(
    ){
        this.Email="";
        this.ConfirmPassword="";
        this.UserName = "";
        this.Password = "";
    }
}