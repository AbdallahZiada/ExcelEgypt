
export class Token {
    constructor(
        public token:string
        ){}
}