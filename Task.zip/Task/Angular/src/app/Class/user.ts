export class User {
        public id:number;
        public name:string;
        public isActive:boolean;
    constructor(
        ){
            this.id;
            this.name="";
            this.isActive;
        }
}
