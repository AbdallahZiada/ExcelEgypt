import { Injectable } from '@angular/core';
import { User } from '../Class/user';
import { HttpHeaders,HttpClient } from '@angular/common/http';
import { Token } from '../Class/token';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment.prod';
import { Router } from '@angular/router';
import { routerNgProbeToken } from '@angular/router/src/router_module';
import { Admin } from '../Class/admin';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  public token:string;
  constructor(
    private httpclient:HttpClient,
    private router:Router
  ) { 
    if(localStorage.getItem("access_token"))
    this.token = localStorage.getItem("access_token");
  }

  ValidateUser(user:Admin):Observable<Token>
  {
    var userData = `{
      Email:    "${user.Email}" ,
      UserName: "${user.Email}",
      Password: "${user.Password}",
      ConfirmPassword:"${user.Password}"
    }`;
    var reqHeader = new HttpHeaders({
      'content-type': 'application/json',
      'Accept': '*/*'
    });
    return this.httpclient.post<Token>(`${environment.API_URL}admin/Login`,userData,{headers:reqHeader});
  }

  register(user:Admin) : Observable<User>
  {
    var userData = `{
      Email:    "${user.Email}" ,
      UserName: "${user.Email}",
      Password: "${user.Password}",
      ConfirmPassword:"${user.ConfirmPassword}"
    }`;
    var reqHeader = new HttpHeaders({
      'content-type': 'application/json',
      'Accept': '*/*'
    });
    return this.httpclient.post<User>(`${environment.API_URL}admin/Register`,userData,{headers:reqHeader});
  }

  RememberToken(accessToken:string)
  {
      localStorage.setItem("access_token",accessToken)  
  }

  IsLoggedIn() :Observable<boolean>
  {
     var reqHeader = new HttpHeaders({
      'content-type': 'application/json',
      'Authorization' : `Bearer ${this.token}`
    });
    return this.httpclient.post<boolean>(`${environment.API_URL}Users/CheckAuth`,{headers:reqHeader});
  
  }

}
