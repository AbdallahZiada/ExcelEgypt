import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment.prod';
import { User } from '../Class/user';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ControlPanelService {
  public token:string;
  constructor(
    private httpclient:HttpClient
  ) { 
    if(localStorage.getItem("access_token"))
    this.token = localStorage.getItem("access_token");
  }

  GetUsers():Observable<User[]>
  {
    var reqHeader = new HttpHeaders({
      'content-type': 'application/json',
      'Authorization' : `Bearer ${this.token}`
    });
    return this.httpclient.get<User[]>(`${environment.API_URL}Users`,{headers:reqHeader});
  }
  AddUser(user:User) : Observable<User>
  {
    var userData = `{
      name: "${user.name}",
      isActive : "${user.isActive}",
    }`;
    var reqHeader = new HttpHeaders({
      'content-type': 'application/json',
      'Authorization' : `Bearer ${this.token}`
    });
    return this.httpclient.post<User>(`${environment.API_URL}Users`,userData,{headers:reqHeader});
  }
  
  UpdateUser(user:User) : Observable<User>
  {
    var userData = `{
      id: "${user.id}",
      name: "${user.name}",
      isActive : "${user.isActive}",
    }`;
    var reqHeader = new HttpHeaders({
      'content-type': 'application/json',
      'Authorization' : `Bearer ${this.token}`
    });
    return this.httpclient.put<User>(`${environment.API_URL}Users/${user.id}`,userData,{headers:reqHeader});
  }

  DeleteUser(id:number) : Observable<User>
  {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization' : `Bearer ${this.token}`
      })
    };
    return this.httpclient.delete<User>(`${environment.API_URL}Users/${id}`,httpOptions);
  }

}
