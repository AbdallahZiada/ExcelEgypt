import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, CanLoad } from '@angular/router';
import { Observable } from 'rxjs';
import { UserService } from './user.service';
// import { AuthService }      from './authentication/services/auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  public authed:boolean;
  public path:string;
  constructor(private router:Router,private userService:UserService)
  {
    this.authed = false;
    this.path="";
  }
  
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      next.url.forEach(x=> this.path = x.path);
      if(localStorage.getItem("access_token"))
          this.authed=true;
      
      if(!this.authed)
        {
          if(this.path=="login")
          {
            var login = true;
          }
          if(this.path=="register")
          {
            var register = true;
          }
          console.log("login2");
          if( login || register )
          {
            return true;
          }
          else{

            return false;
          }
        }
        if(this.authed)
        {
          console.log("login3");
          if(this.path=="login" || this.path=="register")
          {
             return false;
          }
          return true;
        }
  }
}

