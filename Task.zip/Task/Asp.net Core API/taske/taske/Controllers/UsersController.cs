﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Models;
using Repository;

namespace taske.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class UsersController : ControllerBase
    {
        private readonly IUserRepository repository;
        public UsersController(IUserRepository _repository)
        {
            repository = _repository;
        }

        // GET: api/Users
        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> GetUsers()
        {
            var users = repository.GetAllUsers();
            return Ok(users.Result);
        }

        // GET: api/Users/5
        [HttpGet("{id}")]
        public async Task<ActionResult<User>> GetUser(int id)
        {
            var user = repository.GetUser(id);

            if (user == null)
            {
                return NotFound();
            }

            return Ok(user.Result);
        }

        // POST: api/Users
        [HttpPost]
        public async Task<ActionResult<User>> PostUser(User user)
        {
            var registerUser = await repository.RegisterNewUser(user);
            if(registerUser)
                return  Ok(user);
            else
                return BadRequest();
        }

        // PUT: api/Users/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutUser(int id, User user)
        {
            if (id != user.ID)
            {
                return BadRequest();
            }
            var EditedUser = repository.EditUser(id, user);
            if (EditedUser.Result != null)
                return Ok(EditedUser.Result);
            return NoContent();
        }

        // DELETE: api/Users/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<User>> DeleteUser(int id)
        {
            var deletingUser = await repository.DeleteUser(id);
            return Ok(deletingUser);
        }

        [Route("CheckAuth")]
        [HttpPost]
        public bool PostCheckAuth()
        {
            return true;
        }
    }
}
