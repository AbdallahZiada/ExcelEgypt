﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public interface IAdminRepository
    {
        Task<Admin> Register(Admin admin, string password);
        Task<Admin> ValidateAdmin(AdminDTO admin);
        Task<string> GenerateJwtToken(Admin user, string _config);
    }
}
