﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Models;

namespace Repository
{
    public class AdminRepository : IAdminRepository
    {
        private readonly UserManager<Admin> _userManager;
        private readonly SignInManager<Admin> _signInManager;
        public AdminRepository(UserManager<Admin> userManager, SignInManager<Admin> signInManager, IMapper mapper)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }
        public async Task<Admin> Register(Admin admin,string password)
        {
            var result = await _userManager.CreateAsync(admin, password);
            return await _userManager.FindByEmailAsync(admin.Email);
        }

        public async Task<Admin> ValidateAdmin(AdminDTO admin)
        {
            var appUser = new Admin();
            var user1 = await _userManager.FindByEmailAsync(admin.Email);

            var result = await _signInManager
                .CheckPasswordSignInAsync(user1, admin.Password, false);
            if (result.Succeeded)
            {
                appUser = await _userManager.Users
                    .FirstOrDefaultAsync(u => u.Email == admin.Email);
            }
            return appUser;
        }
        public async Task<string> GenerateJwtToken(Admin user, string _config)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.UserName)
            };

            var roles = await _userManager.GetRolesAsync(user);

            foreach (var role in roles)
            {
                claims.Add(new Claim(ClaimTypes.Role, role));
            }

            var key = new SymmetricSecurityKey(Encoding.UTF8
                .GetBytes(_config));

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.Now.AddDays(1),
                SigningCredentials = creds
            };

            var tokenHandler = new JwtSecurityTokenHandler();

            var token = tokenHandler.CreateToken(tokenDescriptor);

            return tokenHandler.WriteToken(token);
        }
    }
}
