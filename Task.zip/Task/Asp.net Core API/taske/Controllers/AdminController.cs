﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using task.Models;

namespace taske.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly IConfiguration _config;
        private readonly IMapper _mapper;
        private readonly UserManager<Admin> _userManager;
        private readonly SignInManager<Admin> _signInManager;

        public AdminController(IConfiguration config,
            IMapper mapper,
            UserManager<Admin> userManager,
            SignInManager<Admin> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _mapper = mapper;
            _config = config;
        }


        // POST api/values
        [Route("register")]
        [HttpPost]
        public async Task<IActionResult> PostRegister(AdminDTO AdminDTO)
        {
            var userToCreate = _mapper.Map<Admin>(AdminDTO);

            var result = await _userManager.CreateAsync(userToCreate, AdminDTO.Password);

            var userToReturn = _mapper.Map<AdminDTO>(userToCreate);

            if (result.Succeeded)
            {
                return Ok(userToReturn);
            }

            return BadRequest(result.Errors);
        }

        [Route("login")]
        [HttpPost]
        public async Task<IActionResult> PostLogin(AdminDTO AdminDTO)
        {
            var user1 = await _userManager.FindByEmailAsync(AdminDTO.Email);

            var result = await _signInManager
                .CheckPasswordSignInAsync(user1, AdminDTO.Password, false);

            if(result.Succeeded)
            {
                var appUser = await _userManager.Users
                    .FirstOrDefaultAsync(u => u.Email == AdminDTO.Email);

                var userToReturn = _mapper.Map<AdminDTO>(appUser);

                return Ok(new
                {
                    token = GenerateJwtToken(appUser).Result
                    //,user = userToReturn
                });
            }
            return Unauthorized();
        }
        private async Task<string> GenerateJwtToken(Admin user)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.UserName)
            };

            var roles = await _userManager.GetRolesAsync(user);

            foreach (var role in roles)
            {
                claims.Add(new Claim(ClaimTypes.Role, role));
            }

            var key = new SymmetricSecurityKey(Encoding.UTF8
                .GetBytes(_config.GetSection("AppSettings:Token").Value));

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.Now.AddDays(1),
                SigningCredentials = creds
            };

            var tokenHandler = new JwtSecurityTokenHandler();

            var token = tokenHandler.CreateToken(tokenDescriptor);

            return tokenHandler.WriteToken(token);
        }

    }
}
